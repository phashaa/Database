-- Create Secondary Filegroup
IF EXISTS (SELECT * FROM sys.filegroups WHERE name = 'SecondaryFG')
    AND NOT EXISTS (SELECT * FROM sys.database_files WHERE data_space_id = 
                   (SELECT data_space_id FROM sys.filegroups WHERE name = 'SecondaryFG'))
BEGIN
    ALTER DATABASE Pizza
    REMOVE FILEGROUP SecondaryFG
END
GO

-- Then create it with a new name
ALTER DATABASE Pizza
ADD FILEGROUP SecondaryFG_New
GO

-- First create directories (run in command prompt)
-- "C:\SQLData"
-- "C:\SQLBackup"
-- These backups will not happen if directories are not created

-- Add file to filegroup with correct path
ALTER DATABASE Pizza
ADD FILE (
    NAME = 'Pizza_Secondary',
    FILENAME = 'C:\SQLData\YourDatabase_Secondary.ndf'
) TO FILEGROUP SecondaryFG_New
GO

-- Full backup
BACKUP DATABASE Pizza
TO DISK = 'C:\SQLBackup\Pizza_Full.bak'
WITH INIT, NAME = 'Full Database Backup'
GO

-- Differential backup
BACKUP DATABASE Pizza
TO DISK = 'C:\SQLBackup\Pizza_Diff.bak'
WITH DIFFERENTIAL, NAME = 'Differential Database Backup'
GO

-- Filegroup backup
BACKUP DATABASE Pizza
FILEGROUP = 'SecondaryFG_New'
TO DISK = 'C:\SQLBackup\Pizza_SecondaryFG.bak'
WITH NAME = 'Secondary FG Backup'
GO

-- Document backup history
SELECT 
    bs.database_name,
    bs.backup_start_date,
    bs.backup_finish_date,
    bs.is_damaged,
    bmf.physical_device_name,

    bs.name AS backup_name
FROM msdb.dbo.backupset bs
JOIN msdb.dbo.backupmediafamily bmf ON bs.media_set_id = bmf.media_set_id
WHERE bs.database_name = 'Pizza'
ORDER BY bs.backup_start_date DESC
GO

--Alternatively you can create backups manually