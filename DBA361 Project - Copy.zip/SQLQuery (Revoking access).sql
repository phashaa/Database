-- Revoke direct table access from all users
REVOKE ALL ON Macy.Users FROM PUBLIC
REVOKE ALL ON Macy.Customers FROM PUBLIC
REVOKE ALL ON Macy.Menu FROM PUBLIC
REVOKE ALL ON Macy.Orders FROM PUBLIC
REVOKE ALL ON Macy.OrderItems FROM PUBLIC
GO
