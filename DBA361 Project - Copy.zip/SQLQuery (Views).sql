-- Creating Views
-- Users View (Sensitive data)
CREATE VIEW Macy.UsersView
AS
SELECT 
    UserID,
    Username,
    Password,
	Role
FROM Macy.Users
GO

-- Customers View
CREATE VIEW Macy.CustomersView
AS
SELECT 
    CustomerID,
    FirstName,
    LastName,
    PhoneNumber
FROM Macy.Customers
GO

-- Menu View
CREATE VIEW Macy.MenuView
AS
SELECT 
    m.MenuID,
    m.DishName,
    m.Description,
    m.Price
FROM Macy.Menu m
GO

-- Orders View
CREATE VIEW Macy.OrdersView
AS
SELECT 
    o.OrderID,
    c.FirstName + ' ' + c.LastName AS CustomerName,
    o.OrderDate,
    o.TotalAmount
FROM Macy.Orders o
LEFT JOIN Macy.Customers c ON o.CustomerID = c.CustomerID
GO

-- Order Items View
CREATE VIEW Macy.OrderItemsView
AS
SELECT 
    oi.OrderItemID,
    o.OrderID,
    m.DishName,
    oi.Quantity,
    oi.Subtotal,
    o.OrderDate
FROM Macy.OrderItems oi
JOIN Macy.Orders o ON oi.OrderID = o.OrderID
JOIN Macy.Menu m ON oi.OrderItemID = m.DishName
GO

-- Daily Sales Report View
CREATE VIEW Macy.DailySalesView
AS
SELECT 
    CAST(o.OrderDate AS DATE) AS SaleDate,
    COUNT(DISTINCT o.OrderID) AS TotalOrders,
    SUM(o.TotalAmount) AS TotalRevenue,
    AVG(o.TotalAmount) AS AverageOrderValue,
    COUNT(DISTINCT o.CustomerID) AS UniqueCustomers
FROM Macy.Orders o
GROUP BY CAST(o.OrderDate AS DATE)
GO



