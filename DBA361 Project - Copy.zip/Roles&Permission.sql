--Creating roles and permission the management and the stuff
CREATE ROLE Macy_Management;
CREATE ROLE Macy_Staff;
GO

CREATE LOGIN ThandoNkosi_Login WITH PASSWORD = 'password123';
CREATE LOGIN SamNkosi_Login WITH PASSWORD = 'password123';
CREATE LOGIN LisaSwaart_Login WITH PASSWORD = 'password123';

CREATE USER ThandoNkosi_User FOR LOGIN ThandoNkosi_Login;
CREATE USER SamNkosi_User FOR LOGIN SamNkosi_Login;
CREATE USER LisaSwaart_User FOR LOGIN LisaSwaart_Login;
GO

EXEC sp_addrolemember 'Macy_Management', 'SamNkosi_User';
EXEC sp_addrolemember 'Macy_Staff', 'ThandoNkosi_User';
EXEC sp_addrolemember 'Macy_Staff', 'LisaSwaart_User';
GO
