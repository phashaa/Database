--Creating primary and secondary filegroup
CREATE DATABASE MacyPizza
ON
(NAME = MacyUserFile,
FILENAME = 'C:\Program Files\Microsoft SQL Server\MSSQL16.SQLEXPRESS\MSSQL\DATA\MacyUserFile.mdf',
SIZE = 10MB,
MAXSIZE = UNLIMITED,
FILEGROWTH = 10%),

FILEGROUP SECONDARY 
(
NAME = MacyDataFile,
FILENAME = 'C:\Program Files\Microsoft SQL Server\MSSQL16.SQLEXPRESS\MSSQL\DATA\MacyDataFile.ndf',
SIZE = 10MB,
MAXSIZE = UNLIMITED,
FILEGROWTH = 10%
)
LOG ON
(
NAME = MacyLogFile,
FILENAME = 'C:\Program Files\Microsoft SQL Server\MSSQL16.SQLEXPRESS\MSSQL\DATA\MacyLogFile.idf',
SIZE = 10MB,
MAXSIZE = UNLIMITED,
FILEGROWTH = 20MB
)

--Full Recovery Model
ALTER DATABASE MacyPizza SET
RECOVERY FULL;

--Auto shrink
ALTER DATABASE MacyPizza SET 
AUTO_SHRINK ON;

--Mode Authentication
EXEC sp_configure 'show advanced options', 1;
RECONFIGURE;

EXEC sp_configure 'authentication mode', 2;
RECONFIGURE;

--System stored produres
--View filegroup information
EXEC sp_helpfile;

--Checking for database recovery model
SELECT name,recovery_model_desc
FROM sys.databases
WHERE name = 'MacyPizza';

--Checking for the database auto shrink settings
SELECT name, is_auto_shrink_on
FROM sys.databases
WHERE name = 'MacyPizza';

--The following example returns information about the Customers table from the MacyPizza database
EXEC sp_statistics Customers;

--Retrieves information for sysname and nvchar data types by specifying the data type value of -9.
USE [Pizzaria_V2]
GO
EXEC sp_datatype_info -9;
GO