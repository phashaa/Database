
---Windows performance monitor
--Checking the memory pressure
EXEC sp_configure 'max server memory (MB)', 8192;  
RECONFIGURE;

--Checking for disk latency
SELECT 
    database_id, file_id, io_stall_read_ms, io_stall_write_ms, num_of_reads, num_of_writes
FROM sys.dm_io_virtual_file_stats(NULL, NULL);

CREATE EVENT SESSION MacyPizzaMonitor
ON SERVER
ADD EVENT
sqlserver.sql_batch_completed
(
ACTION 
(sqlserver.sql_text, sqlserver.session_id)
WHERE(duration > 1000000)
)
ADD TARGET package0.event_file
(
SET filename = 'C:\Program Files\Microsoft SQL Server\MSSQL16.SQLEXPRESS\MSSQL\DATA\MacyPizzaMonitor.xel'
);
GO

--The monitoring session
ALTER EVENT SESSION
MacyPizzaMonitor ON SERVER STATE = START;
GO

--Stopping the monitoring session
ALTER EVENT SESSION MacyPizzaMonitor ON SERVER STATE = STOP;
GO

--The DBCC Command
DBCC CHECKTABLE(Customers); 
DBCC CHECKDB([Pizzaria_V2]);

--The DMV
SELECT * FROM sys.dm_exec_requests; 
SELECT * FROM sys.dm_exec_sessions

--sql profiler

--SQL Server Extended Events
--Viewing the extended events
SELECT s.name, st.target_name, st.target_data
FROM sys.dm_xe_sessions s
INNER JOIN 
sys.dm_xe_session_targets st 
ON  s.address = st.event_session_address
WHERE s.NAME = 'system_health';

--This function reads the system_health event session file data
SELECT object_name, event_data 
FROM 
sys.fn_xe_file_target_read_file('system_health*.xel', null,null,null);
