-- Create the Management role
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = 'Management' AND type = 'R')
BEGIN
    CREATE ROLE Management
END
GO

-- Now you can grant permissions to the Management role
GRANT SELECT, INSERT, UPDATE, DELETE ON Macy.CustomersView TO Management
GRANT SELECT, INSERT, UPDATE, DELETE ON Macy.MenuView TO Management
GRANT SELECT, INSERT, UPDATE, DELETE ON Macy.OrdersView TO Management
GRANT SELECT, INSERT, UPDATE, DELETE ON Macy.OrderItemsView TO Management
GRANT SELECT, INSERT, UPDATE, DELETE ON Macy.DailySalesView TO Management
GRANT SELECT ON Macy.UsersView TO Management
GO

-- Permissions to Staff role
GRANT SELECT ON Macy.CustomersView TO Staff
GRANT SELECT ON Macy.MenuView TO Staff
GRANT SELECT, INSERT, UPDATE ON Macy.OrdersView TO Staff
GRANT SELECT, INSERT, UPDATE ON Macy.OrderItemsView TO Staff
GRANT SELECT ON Macy.DailySalesView TO Staff
GO


