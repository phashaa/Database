-- 1. Server Logins
SELECT name,
       type_desc,
       is_disabled
FROM sys.server_principals
WHERE type IN ('S', 'U', 'G')  -- SQL logins, Windows logins, Windows groups
ORDER BY type_desc, name;

-- 2. Database Users and Roles
SELECT u.name AS DatabaseUser,
       u.type_desc AS UserType,
       r.name AS RoleName
FROM sys.database_principals u
LEFT JOIN sys.database_role_members rm 
    ON u.principal_id = rm.member_principal_id
LEFT JOIN sys.database_principals r 
    ON rm.role_principal_id = r.principal_id
WHERE u.type IN ('S', 'U', 'G', 'R')  -- SQL users, Windows users, Groups, Roles
ORDER BY u.type_desc, u.name;

-- 3. View Permissions in Macy Schema
SELECT SCHEMA_NAME(v.schema_id) AS SchemaName,
       v.name AS ViewName,
       u.name AS PrincipalName,
       u.type_desc AS PrincipalType,
       p.permission_name,
       p.state_desc AS PermissionState
FROM sys.views v
JOIN sys.database_permissions p 
    ON p.major_id = v.object_id
JOIN sys.database_principals u 
    ON p.grantee_principal_id = u.principal_id
WHERE v.schema_id = SCHEMA_ID('Macy')
ORDER BY SchemaName, ViewName, PrincipalName;

